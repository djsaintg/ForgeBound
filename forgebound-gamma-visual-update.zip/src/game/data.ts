import type {
  ItemDef,
  ItemId,
  RecipeDef,
  RecipeId,
  ResKey,
  ResourceDef,
  StationId,
} from "./types";

export const ITEMS: Record<ItemId, ItemDef> = {
  coins: { id: "coins", name: "Coins", cat: "currency", stackable: true, price: 1 },
  logs: { id: "logs", name: "Logs", cat: "resource", stackable: false, price: 12 },
  oak_logs: { id: "oak_logs", name: "Oak logs", cat: "resource", stackable: false, price: 30 },
  copper_ore: { id: "copper_ore", name: "Copper ore", cat: "ore", stackable: false, price: 10 },
  tin_ore: { id: "tin_ore", name: "Tin ore", cat: "ore", stackable: false, price: 10 },
  iron_ore: { id: "iron_ore", name: "Iron ore", cat: "ore", stackable: false, price: 30 },
  coal: { id: "coal", name: "Coal", cat: "ore", stackable: false, price: 60 },
  gold_ore: { id: "gold_ore", name: "Gold ore", cat: "ore", stackable: false, price: 150 },
  raw_shrimp: { id: "raw_shrimp", name: "Raw shrimp", cat: "raw_fish", stackable: false, price: 8 },
  shrimp: { id: "shrimp", name: "Shrimp", cat: "food", stackable: false, price: 15, heal: 3 },
  raw_trout: { id: "raw_trout", name: "Raw trout", cat: "raw_fish", stackable: false, price: 40 },
  trout: { id: "trout", name: "Trout", cat: "food", stackable: false, price: 85, heal: 7 },
  bronze_bar: { id: "bronze_bar", name: "Bronze bar", cat: "bar", stackable: false, price: 50 },
  iron_bar: { id: "iron_bar", name: "Iron bar", cat: "bar", stackable: false, price: 110 },
  steel_bar: { id: "steel_bar", name: "Steel bar", cat: "bar", stackable: false, price: 260 },
  bronze_dagger: { id: "bronze_dagger", name: "Bronze dagger", cat: "weapon", stackable: false, price: 80, tier: 1 },
  iron_dagger: { id: "iron_dagger", name: "Iron dagger", cat: "weapon", stackable: false, price: 190, tier: 2 },
  steel_dagger: { id: "steel_dagger", name: "Steel dagger", cat: "weapon", stackable: false, price: 480, tier: 3 },
  bronze_axe: { id: "bronze_axe", name: "Bronze axe", cat: "axe", stackable: false, price: 150, tier: 1 },
  iron_axe: { id: "iron_axe", name: "Iron axe", cat: "axe", stackable: false, price: 500, tier: 2 },
  steel_axe: { id: "steel_axe", name: "Steel axe", cat: "axe", stackable: false, price: 1400, tier: 3 },
  mithril_axe: { id: "mithril_axe", name: "Mithril axe", cat: "axe", stackable: false, price: 4000, tier: 4 },
  bronze_pick: { id: "bronze_pick", name: "Bronze pickaxe", cat: "pick", stackable: false, price: 150, tier: 1 },
  iron_pick: { id: "iron_pick", name: "Iron pickaxe", cat: "pick", stackable: false, price: 500, tier: 2 },
  steel_pick: { id: "steel_pick", name: "Steel pickaxe", cat: "pick", stackable: false, price: 1400, tier: 3 },
  mithril_pick: { id: "mithril_pick", name: "Mithril pickaxe", cat: "pick", stackable: false, price: 4000, tier: 4 },
  fly_rod: { id: "fly_rod", name: "Fly fishing rod", cat: "rod", stackable: false, price: 80, tier: 1 },
  // Combat & Livestock Drops
  bones: { id: "bones", name: "Bones", cat: "bone", stackable: false, price: 10 },
  raw_beef: { id: "raw_beef", name: "Raw beef", cat: "raw_food", stackable: false, price: 15 },
  cooked_beef: { id: "cooked_beef", name: "Steak", cat: "food", stackable: false, price: 90, heal: 9 },
  raw_chicken: { id: "raw_chicken", name: "Raw chicken", cat: "raw_food", stackable: false, price: 10 },
  cooked_chicken: { id: "cooked_chicken", name: "Cooked chicken", cat: "food", stackable: false, price: 30, heal: 4 },
  feathers: { id: "feathers", name: "Feathers", cat: "resource", stackable: true, price: 3 },
  egg: { id: "egg", name: "Farm egg", cat: "raw_food", stackable: false, price: 8 },
  fried_egg: { id: "fried_egg", name: "Fried egg", cat: "food", stackable: false, price: 20, heal: 3 },
  bronze_sword: { id: "bronze_sword", name: "Bronze sword", cat: "weapon", stackable: false, price: 120, tier: 1 },
  bronze_platebody: { id: "bronze_platebody", name: "Bronze platebody", cat: "armor", stackable: false, price: 250, tier: 1 },
};

export const RESOURCES: Record<ResKey, ResourceDef> = {
  tree: { key: "tree", name: "Tree", skill: "woodcutting", item: "logs", xp: 25, level: 1, tool: "axe", cycle: 2400, respawn: 12000 },
  oak: { key: "oak", name: "Oak tree", skill: "woodcutting", item: "oak_logs", xp: 40, level: 15, tool: "axe", cycle: 2800, respawn: 18000 },
  copper: { key: "copper", name: "Copper rocks", skill: "mining", item: "copper_ore", xp: 18, level: 1, tool: "pick", cycle: 2600, respawn: 8000 },
  tin: { key: "tin", name: "Tin rocks", skill: "mining", item: "tin_ore", xp: 18, level: 1, tool: "pick", cycle: 2600, respawn: 8000 },
  iron: { key: "iron", name: "Iron rocks", skill: "mining", item: "iron_ore", xp: 35, level: 10, tool: "pick", cycle: 3000, respawn: 12000 },
  coal: { key: "coal", name: "Coal rocks", skill: "mining", item: "coal", xp: 50, level: 20, tool: "pick", cycle: 3200, respawn: 16000 },
  gold: { key: "gold", name: "Gold rocks", skill: "mining", item: "gold_ore", xp: 65, level: 40, tool: "pick", cycle: 3600, respawn: 24000 },
  shrimp: { key: "shrimp", name: "Shrimp swarm", skill: "fishing", item: "raw_shrimp", xp: 10, level: 1, cycle: 2000, respawn: 0 },
  trout: { key: "trout", name: "Trout current", skill: "fishing", item: "raw_trout", xp: 50, level: 20, tool: "rod", cycle: 2400, respawn: 0 },
};

export const OBJ_TO_RES: Record<string, ResKey> = {
  T: "tree",
  O: "oak",
  R: "copper",
  S: "tin",
  I: "iron",
  C: "coal",
  G: "gold",
  f: "shrimp",
  t: "trout",
};

export const OBJ_TO_STATION: Record<string, StationId | "bank"> = {
  F: "furnace",
  A: "anvil",
  "*": "fire",
  B: "bank",
};

export const STATION_NAMES: Record<StationId, string> = {
  furnace: "Furnace",
  anvil: "Anvil",
  fire: "Campfire",
};

export const RECIPES: RecipeDef[] = [
  { id: "smelt_bronze", name: "Smelt bronze bar", station: "furnace", skill: "smithing", level: 1, xp: 6.2, cycle: 2200, inputs: { copper_ore: 1, tin_ore: 1 }, output: "bronze_bar" },
  { id: "smelt_iron", name: "Smelt iron bar", station: "furnace", skill: "smithing", level: 15, xp: 12.5, cycle: 2400, inputs: { iron_ore: 1 }, output: "iron_bar" },
  { id: "smelt_steel", name: "Smelt steel bar", station: "furnace", skill: "smithing", level: 30, xp: 17.5, cycle: 2600, inputs: { iron_ore: 1, coal: 2 }, output: "steel_bar" },
  { id: "smith_bronze_dagger", name: "Smith bronze dagger", station: "anvil", skill: "smithing", level: 1, xp: 12.5, cycle: 2400, inputs: { bronze_bar: 1 }, output: "bronze_dagger" },
  { id: "smith_iron_dagger", name: "Smith iron dagger", station: "anvil", skill: "smithing", level: 15, xp: 25, cycle: 2600, inputs: { iron_bar: 1 }, output: "iron_dagger" },
  { id: "smith_steel_dagger", name: "Smith steel dagger", station: "anvil", skill: "smithing", level: 30, xp: 37.5, cycle: 2800, inputs: { steel_bar: 1 }, output: "steel_dagger" },
  { id: "smith_bronze_sword", name: "Smith bronze sword", station: "anvil", skill: "smithing", level: 3, xp: 18, cycle: 2500, inputs: { bronze_bar: 1 }, output: "bronze_sword" },
  { id: "smith_bronze_platebody", name: "Smith bronze armor", station: "anvil", skill: "smithing", level: 5, xp: 45, cycle: 3200, inputs: { bronze_bar: 3 }, output: "bronze_platebody" },
  { id: "cook_shrimp", name: "Cook shrimp", station: "fire", skill: "cooking", level: 1, xp: 30, cycle: 2000, inputs: { raw_shrimp: 1 }, output: "shrimp" },
  { id: "cook_trout", name: "Cook trout", station: "fire", skill: "cooking", level: 15, xp: 70, cycle: 2400, inputs: { raw_trout: 1 }, output: "trout" },
  { id: "cook_beef", name: "Cook steak", station: "fire", skill: "cooking", level: 15, xp: 70, cycle: 2400, inputs: { raw_beef: 1 }, output: "cooked_beef" },
  { id: "cook_chicken", name: "Roast chicken", station: "fire", skill: "cooking", level: 1, xp: 30, cycle: 2000, inputs: { raw_chicken: 1 }, output: "cooked_chicken" },
  { id: "cook_egg", name: "Fry farm egg", station: "fire", skill: "cooking", level: 1, xp: 20, cycle: 1800, inputs: { egg: 1 }, output: "fried_egg" },
];

export const RECIPE_BY_ID: Record<RecipeId, RecipeDef> = Object.fromEntries(
  RECIPES.map((r) => [r.id, r])
) as Record<RecipeId, RecipeDef>;

export const SHOP_STOCK: ItemId[] = [
  "bronze_axe",
  "iron_axe",
  "steel_axe",
  "mithril_axe",
  "bronze_pick",
  "iron_pick",
  "steel_pick",
  "mithril_pick",
  "fly_rod",
  "bronze_sword",
  "bronze_platebody",
];

/** Attempt-cycle speed multiplier by equipped tool tier (0 = bare hands / no tool). */
export const TOOL_SPEED: Record<number, number> = { 0: 1.55, 1: 1, 2: 0.85, 3: 0.72, 4: 0.6 };

export const MARO_LINES = [
  "Welcome to ForgeBound! You can engage in combat with cows in the north pasture, chickens in the S.E. coop, or the goblins of Grublin Gully to the N.E.!",
  "Goblins carry coins and sometimes drop bronze swords or platebodies when vanquished. Pick up their dropped loot from the ground!",
  "Chickens regularly lay fresh farm eggs in the coop straw! Gather eggs, raw beef, and raw chicken to cook over the campfire.",
  "Don't forget to bury monster bones from your backpack—it honors the departed and earns valuable Prayer XP!",
  "Chop trees in the Westwood, then smelt copper and tin into bronze at the furnace north of Vale Square.",
  "Keldrek Mine is east along the road. Iron hides at level 10, coal at 20, and gold at 40.",
  "Everything you own can be banked at the booth. Try toggling between 8-bit Legacy and 64-bit Remastered mode in the settings!",
];

export const SELL_RATIO = 0.55;
